<?php

class ChartPosition {
    const BEFORE_GRID = 'BEFORE_GRID';
    const AFTER_GRID = 'AFTER_GRID';
}
